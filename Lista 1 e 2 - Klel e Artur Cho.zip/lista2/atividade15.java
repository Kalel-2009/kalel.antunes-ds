import java.util.Scanner;

public class atividade15 {
 
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         
          System.out.println("Escreva o preço do produto: ");
          double pre = scanner.nextDouble();
          
          if (pre < 50 ) {
            
             double desc = pre * 0.05;
             double pre2 = pre - desc;
             System.out.println("seu desconto será de R$" + desc + ". O preço será de R$" + pre2); 
          }
          
          else if (pre < 100 && pre >= 50 ) {
            
             double desc = pre * 0.10;
             double pre2 = pre - desc;
             System.out.println("seu desconto será de R$" + desc + ". O preço será de R$" + pre2); 
          }
          
          else if (pre > 100 ) {
            
             double desc = pre * 0.15;
             double pre2 = pre - desc;
             System.out.println("seu desconto será de R$" + desc + ". O preço será de R$" + pre2); 
          }
     
             
     scanner.close(); 

} 
    
}
