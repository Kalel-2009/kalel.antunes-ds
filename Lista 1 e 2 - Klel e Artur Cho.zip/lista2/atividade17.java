import java.util.Scanner;

public class atividade17 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva um número: ");
        int num = scanner.nextInt();

        System.out.println("Escreva outro número: ");
        int num2 = scanner.nextInt();


        if (num > 0 && num2 > 0) {
            int soma = num + num2;
            System.out.println("O resultado da soma dos dois números será: " + soma);
        } 
        else  {
            System.out.println("valores inválidos.");
        } 
       

        scanner.close();
    }
    
}
