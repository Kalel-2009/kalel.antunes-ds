import java.util.Scanner;

public class exercicio8 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o salário: ");
        int sal = scanner.nextInt();
        
        System.out.print("Digite o valor da parcela: ");
        int par = scanner.nextInt();
        
        if (par <= (sal*0.3)) {
            
            System.out.print("empréstimo aprovado");
        }
        
        else {
            
            System.out.println("empréstimo negado");
        }

        scanner.close();
    }
}