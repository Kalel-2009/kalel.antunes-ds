import java.util.Scanner;

public class atividade13 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite sua altura: ");
        double h = scanner.nextDouble();
        
        System.out.println("Digite seu peso: ");
        double peso = scanner.nextDouble();

        System.out.println("Digite seu sexo (H/M): ");
        String sexo = scanner.next();
        
        if (sexo.equalsIgnoreCase("H")) {
            double pesoIdeal = (72.7 * h) - 58;

            if (pesoIdeal > peso) {
                System.out.println("Abaixo do peso");
            } else if (pesoIdeal < peso) {
                System.out.println("Acima do peso");
            } else {
                System.out.println("Peso ideal");
            }

        } else if (sexo.equalsIgnoreCase("M")) {
            double pesoIdeal = (62.1 * h) - 44.7;

            if (pesoIdeal > peso) {
                System.out.println("Abaixo do peso");
            } else if (pesoIdeal < peso) {
                System.out.println("Acima do peso");
            } else {
                System.out.println("Peso ideal");
            }

        } else {
            System.out.println("Sexo inválido");
        }

        scanner.close();
    }
}