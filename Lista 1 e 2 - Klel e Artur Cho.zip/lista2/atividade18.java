import java.util.Scanner;

public class atividade18 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva a quantidade de segundos: ");
        int seg = scanner.nextInt();


        int horas = (seg/60)/60;
        int resto = seg % 3600;
        int min = resto / 60;
        int segresto = resto % 60;

        System.out.println("O total de horas será de: " + horas + "h.");
        System.out.println("O total de horas será de: " + min + "min.");
        System.out.println("O total de horas será de: " + segresto + "seg.");

        scanner.close();
    }
    
}
