import java.util.Scanner;

public class exercicio1 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite um numero: ");
        double num = scanner.nextDouble();

        System.out.println("seu dobro é " + (num*2) + " e seu triplo é "+ (num*3));

        scanner.close();
    }
}