import java.util.Scanner;

public class atividade20 {
 
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         
          System.out.println("Escreva o valor da venda: ");
          double pre = scanner.nextDouble();
          
          if (pre < 1000 ) {
            
             double com = pre * 0.04;
             System.out.println("A sua comissão será de R$" + com); 

          }
          
          else if (pre >= 1000 && pre <= 5000 ) {
            
             double com = pre * 0.06;
             System.out.println("Sua comissão será de R$" + com); 

          }
          
          else if (pre > 5000) {
            
             double com = pre * 0.08;
             System.out.println("Sua comissão será de R$" + com); 

          }
     
             
     scanner.close(); 

} 
    
}
