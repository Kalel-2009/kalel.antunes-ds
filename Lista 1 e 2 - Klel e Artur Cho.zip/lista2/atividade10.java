import java.util.Scanner;

public class atividade10 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva um número: ");
        int num = scanner.nextInt();
        
        System.out.println("Escreva outro número: ");
        int num2 = scanner.nextInt();
        
        int dife = Math.abs( num - num2 );
        
        System.out.println("Então a diferença absoluta entre os dois números será: " + dife);


        scanner.close();
    }
}