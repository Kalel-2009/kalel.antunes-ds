import java.util.Scanner;

public class exercicio6 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número: ");
        int num = scanner.nextInt();

        if (num % 2 == 0) {
            System.out.println("O número é par");
        } else {
            System.out.println("O número é ímpar");
        }

        if (num % 5 == 0) {
            System.out.println("O número é divisível por 5");
        } else {
            System.out.println("O número NÃO é divisível por 5");
        }

        scanner.close();
    }
}