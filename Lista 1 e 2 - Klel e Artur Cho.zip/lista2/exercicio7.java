import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a distância: ");
        int dist = scanner.nextInt();
        
        
        System.out.print("Digite a velocidade média (km/h) : ");
        int vel = scanner.nextInt();
        
        System.out.print("o tempo será de: " + (dist / vel));

        scanner.close();
    }
}