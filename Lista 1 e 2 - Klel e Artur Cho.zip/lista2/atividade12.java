import java.util.Scanner;

public class atividade12{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva quantos reais você quer converter: ");
        int a = scanner.nextInt();
        
        double quant = a / 5.31;
        
        
        
        System.out.println("Você poderá comprar $" + quant);
        

        scanner.close( );
    }
}