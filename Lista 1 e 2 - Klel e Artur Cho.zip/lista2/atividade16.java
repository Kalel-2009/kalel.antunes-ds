import java.util.Scanner;

public class atividade16 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva um número: ");
        int num = scanner.nextInt();


        if (num >= 10 && num <= 50) {
            System.out.println("O número está no intervalo de [10,50].");
        } 
        else  {
            System.out.println("O número não está no intervalo de [10,50].");
        } 
       

        scanner.close();
    }
    
}
