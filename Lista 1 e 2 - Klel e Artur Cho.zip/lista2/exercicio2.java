import java.util.Scanner;

public class exercicio2 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite uma quantidade de horas: ");
        double horas = scanner.nextDouble();

        System.out.println("essa quantidade de horas em minutos é igual a " + (horas*60));

        scanner.close();
    }
}