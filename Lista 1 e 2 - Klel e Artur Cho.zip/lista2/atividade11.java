import java.util.Scanner;

public class atividade11{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva um número: ");
        int a = scanner.nextInt();
        
        System.out.println("Escreva outro número: ");
        int b = scanner.nextInt();
        
        System.out.println("Escreva outro número: ");
        int c = scanner.nextInt();
        
        if (a<b & b<c){
           
           System.out.println("Então a ordem crescente será: " + a + b + c );
            
        }
        
        else if (b<a & a<c) {
           
           System.out.println("Então em ordem crescente será: " + b + a + c );
            
        }
        
        else if (b<a & c<b) {
           
           System.out.println("Então em ordem crescente será: " + c + b + a );
            
        }
        
        else if (a<c & c<b) {
           
           System.out.println("Então em ordem crescente será: " + a + c + b );
            
        }
        
        else if (b<c & a>c) {
           
           System.out.println("Então em ordem crescente será: " + b + c + a );
            
        }
        
        else if (c<a & a<b) {
           
           System.out.println("Então em ordem crescente será: " + c +" - "+ a +" - "+ b );
            
        }

        scanner.close( );
    }
}