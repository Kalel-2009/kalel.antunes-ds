import java.util.Scanner;

public class exercicio4 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor do produto: ");
        double valor = scanner.nextDouble();
        
        double valor_final = valor + (valor*0.05) + (valor*0.07);

        System.out.println("O valor final será: " + (valor_final));
    

        scanner.close();
    }
}