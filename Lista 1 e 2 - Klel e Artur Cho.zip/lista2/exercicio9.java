import java.util.Scanner;

public class exercicio9 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o salário: ");
        double sal = scanner.nextDouble();

        double desconto;

        if (sal < 2000) {
            desconto = sal * 0.08;
        } 
        
        else if (sal <= 3000) {
            desconto = sal * 0.09;
        } 
        
        else {
            desconto = sal * 0.11;
        }

        double salLiquido = sal - desconto;

        System.out.printf("Desconto INSS: R$ %.2f%n", desconto);
        System.out.printf("Salário líquido: R$ %.2f%n", salLiquido);

        scanner.close();
    }
}