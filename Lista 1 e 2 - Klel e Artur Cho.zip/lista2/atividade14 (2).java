import java.util.Scanner;

public class atividade14 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva a primeira nota: ");
        int nota = scanner.nextInt();

        System.out.println("Escreva a segunda nota: ");
        int nota2 = scanner.nextInt();

        double media = (nota + nota2)/2;

        if (media >= 6) {
            System.out.println("Você está aprovado.");
        } 
        else  {
            System.out.println("Você está reprovado.");
        } 
       

        scanner.close();
    }
}