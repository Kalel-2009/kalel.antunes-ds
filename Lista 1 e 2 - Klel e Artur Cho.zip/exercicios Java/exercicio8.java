 import java.util.Scanner;
 
 public class exercicio8 { 
    
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
          
          System.out.println("Escreva o preço do produto: ");
          double pre = scanner.nextInt();
          
          if (pre > 100) 
          
          { double desc = pre * 0.20; double pre2 = pre - desc;
          
          System.out.println("O desconto será de R$ "+ desc + " assim o valor final será R$" + pre2);
          }
           else { 
                
                double desc = pre * 0.10; double pre2 = pre - desc;
                System.out.println("O desconto será de R$ " + desc + " assim o valor final será R$ " + pre2 );
                
     } scanner.close(); 

}

}