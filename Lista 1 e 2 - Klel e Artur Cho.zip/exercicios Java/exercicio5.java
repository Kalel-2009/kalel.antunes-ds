import java.util.Scanner;
 
 public class exercicio5 {
    
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         
          System.out.println("Escreva seu salário: ");
          int sal = scanner.nextInt();
          
          if (sal < 2000 ) {
            
             double aumento = sal * 0.10;
             double sal2 = sal + aumento;
             System.out.println("seu aumento será de R$" + aumento + ". O seu salário será de R$" + sal2); 
          }
          else if (sal >= 2000 && sal <= 4000) {

             double aumento = sal * 0.07;
             double sal2 = sal + aumento;
             System.out.println("seu aumento será de R$"+ aumento + ". O seu salário será de R$" + sal2);
              }
          else if (sal > 4000) {

             double aumento = sal * 0.05;
             double sal2 = sal + aumento;
             System.out.println("seu aumento será de R$" + aumento + ". O seu salário será de R$" + sal2); }
             
     scanner.close(); 

} 

}