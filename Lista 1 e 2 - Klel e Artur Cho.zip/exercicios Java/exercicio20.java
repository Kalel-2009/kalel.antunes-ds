import java.util.Scanner;

public class exercicio20 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o lado 1: ");
        double a = scanner.nextDouble();

        System.out.print("Digite o lado 2: ");
        double b = scanner.nextDouble();

        System.out.print("Digite o lado 3: ");
        double c = scanner.nextDouble();

        if (a < b + c && b < a + c && c < a + b) {

            if (a == b && b == c) {
                System.out.println("Equilátero");
            } else if (a == b || a == c || b == c) {
                System.out.println("Isósceles");
            } else {
                System.out.println("Escaleno");
            }

        } else {
            System.out.println("Não é um triângulo");
        }

        scanner.close();
    }
}