import java.util.Scanner;

public class exercicio12 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva seu primeiro numero: ");
        int num = scanner.nextInt();

        System.out.println("Escreva sua segundo numero: ");
        int num2 = scanner.nextInt();

        System.out.println("Escolha a operação: (+ | - | x | / )");
        String operador = scanner.next();

        if (operador.equals ("+")) {
            System.out.println(num + num2);
        } 
        else if (operador.equalsIgnoreCase ("-")) {
            System.out.println(num - num2);
        } 
        else if (operador.equalsIgnoreCase ("x")){
            System.out.println(num * num2);
        }
         else if (operador.equals ("/")) {
             
            System.out.println(num / num2);
             
         }

        scanner.close();
    }
}