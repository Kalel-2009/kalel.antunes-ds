import java.util.Scanner;

public class exercicio4 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva sua primeira nota: ");
        int num = scanner.nextInt();

        System.out.println("Escreva sua segunda nota: ");
        int num2 = scanner.nextInt();

        System.out.println("Escreva sua terceira nota: ");
        int num3 = scanner.nextInt();

        double media = (num + num2 + num3) / 3.0;

        if (media >= 7) {
            System.out.println("Você está aprovado.");
        } 
        else if (media >= 5 && media < 7) {
            System.out.println("Você está de recuperação.");
        } 
        else {
            System.out.println("Você está reprovado.");
        }

        scanner.close();
    }
}