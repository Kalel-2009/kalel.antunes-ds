import java.util.Scanner;

public class exercicio13 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva sua nota: ");
        int nota = scanner.nextInt();

        if (nota > 10 && nota < 0) {
            System.out.println("é inválido");
        } 
        else {
            System.out.println("é válido");
        } 
        
        scanner.close();
    }
}