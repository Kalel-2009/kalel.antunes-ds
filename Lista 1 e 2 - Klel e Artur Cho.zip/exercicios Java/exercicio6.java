import java.util.Scanner;

 public class exercicio6 {
    
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         
          System.out.println("Escreva sua idade: ");
          int idade = scanner.nextInt();
          
           if (idade < 16 ) {
            
             System.out.println("Você não pode votar."); 
             }
           else if (idade >= 18 && idade < 75) {
            
             System.out.println("Você é obrigado a votar."); 
             }
            else if (idade >= 16 && idade < 18) {
                
                 System.out.println("Você já pode votar, mas não é obrigatório."); 
                }
             else {
                
                 System.out.println("Você pode votar, mas não é obrigatório."); } 
            
    scanner.close(); 

} 
}