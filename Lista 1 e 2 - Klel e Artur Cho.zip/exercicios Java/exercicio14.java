import java.util.Scanner;

public class exercicio14 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Qual será a distância percorrida?: ");
        double dist = scanner.nextDouble();

        System.out.println("Qual é o consumo do carro por litro?");
        double consumo = scanner.nextDouble();
        
        System.out.println("O gasto em litros será de: " + (dist / consumo));




        scanner.close();
    }
}