import java.util.Scanner;
 public class exercicio11 
 { public static void main(String[] args) { 

    Scanner scanner = new Scanner(System.in);
     System.out.println("Escreva o ano: ");
     
      int ano = scanner.nextInt(); if ((ano % 4 == 0 && ano % 100 != 0 ) || (ano % 400 == 0)) {

         System.out.println("O seu ano é bissexto."); } 

         else {
             System.out.println("O seu ano não é bissexto"); } 
             
             scanner.close(); 
         
 } 
         
}