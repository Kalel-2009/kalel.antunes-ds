import java.util.Scanner;
 public class exercicio9 {

     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         
         System.out.println("Escreva o primeiro número: ");
          int num1 = scanner.nextInt(); System.out.println("Escreva o segundo número: ");
          
          int num2 = scanner.nextInt(); 
          
        if (num1 % num2 == 0) {

             System.out.println("O "+ num1 + " é um multiplo de " + num2); } 
             
        else {
             
            System.out.println("O "+ num1 + " não é um multiplo de " + num2); }
            
     scanner.close(); 

}

}