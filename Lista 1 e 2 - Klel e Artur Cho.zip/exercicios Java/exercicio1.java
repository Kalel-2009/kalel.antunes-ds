import java.util.Scanner;
public class exercicio1 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Escreva um numero: ");
        int numero = scanner.nextInt();
        
        if (numero % 2 == 0)
        {
            System.out.println("Seu numero e par.");
            
        }
        else {
            System.out.println("Seu numero e impar.");
        }
    }
    
}
