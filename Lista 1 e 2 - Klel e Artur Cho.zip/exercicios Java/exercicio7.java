  import java.util.Scanner;

public class exercicio7 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva a temperatura atual em Celsius: ");
        int temp = scanner.nextInt();

        Double fahren = ( temp * 1.8) + 32.00;

        System.out.println("Escreva a temperatura atual em Fahrenheit é de : " + fahren + "°F.");
        




        scanner.close();
    }
}
