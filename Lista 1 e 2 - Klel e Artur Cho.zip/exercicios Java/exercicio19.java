import java.util.Scanner;

public class exercicio19 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        double n1 = scanner.nextDouble();

        System.out.print("Digite o segundo número: ");
        double n2 = scanner.nextDouble();

        System.out.print("Digite o terceiro número: ");
        double n3 = scanner.nextDouble();

        double menor;

        if (n1 <= n2 && n1 <= n3) {
            menor = n1;
        } 
        
        else if (n2 <= n1 && n2 <= n3) {
            menor = n2;
        } 
        
        else {
            menor = n3;
        }

        System.out.println("O menor número é: " + menor);

        scanner.close();
    }
}