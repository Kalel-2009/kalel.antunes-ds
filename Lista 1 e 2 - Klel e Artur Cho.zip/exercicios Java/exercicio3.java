import java.util.Scanner;

public class exercicio3 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva um número: ");
        int num = scanner.nextInt();

        if (num > 0) {
            System.out.println("O seu número é positivo.");
        } 
        else if (num < 0) {
            System.out.println("O seu número é negativo.");
        } 
        else {
            System.out.println("O seu número é 0.");
        }

        scanner.close();
    }
}