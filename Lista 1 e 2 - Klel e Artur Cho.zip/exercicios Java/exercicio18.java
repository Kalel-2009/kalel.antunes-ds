import java.util.Scanner;

public class exercicio18 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o consumo em kWh: ");
        double consumo = scanner.nextDouble();

        double preco;
        double total;

        if (consumo < 100) {
            preco = 0.20;
        } 
        
        else {
            preco = 0.25;
        }

        total = consumo * preco;

        System.out.println("Valor a pagar: " + total);

        scanner.close();
    }
}