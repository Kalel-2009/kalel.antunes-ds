import java.util.Scanner;

public class exercicio10 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite sua altura: ");
        double h = scanner.nextDouble();

        System.out.println("Digite seu sexo (H para homem / M para mulher): ");
        String sexo = scanner.next();

        if (sexo.equalsIgnoreCase("H")) {
            double peso = (72.7 * h) - 58;
            System.out.println("Seu peso ideal é: " + peso);
        }
        else if (sexo.equalsIgnoreCase("M")) {
            double peso = (62.1 * h) - 44.7;
            System.out.println("Seu peso ideal é: " + peso);
        }
        else {
            System.out.println("Sexo inválido.");
        }

        scanner.close();
    }
}