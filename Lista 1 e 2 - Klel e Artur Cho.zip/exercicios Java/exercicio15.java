import java.util.Scanner;

 public class exercicio15 {
    
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         
          System.out.println("Escreva uma idade: ");
          int idade = scanner.nextInt();
          
           if (idade < 12 ) {
            
             System.out.println("Idade de criança"); 
             }
           else if (idade >= 13 && idade <= 17 ) {
            
             System.out.println("Idade de adolescente."); 
             }
            else if (idade >= 18 && idade <= 59) {
                
                 System.out.println("Idade de adulto.."); 
                }
             else {
                
                 System.out.println("idade de idoso."); } 
            
    scanner.close(); 

} 
}