import java.util.Scanner;

public class exercicio17 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Escreva sua nota: ");
        int nota = scanner.nextInt();
        
        System.out.println("Escreva sua frequência em %: ");
        int freq = scanner.nextInt();

        if (nota >= 7 && freq >= 75) {
            System.out.println("aprovado");
        } 
        else {
            System.out.println("reprovado");
        } 
        
        scanner.close();
    }
}