import java.util.Scanner;

public class Ex15
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);
		
		int resposta;
		
		System.out.println("Você é feio? (Sim = 1 ; Não = 2)");
		resposta = scanner.nextInt();
		
		while (resposta == 2) 
		{
		    
		    System.out.println("Mente que nem sente.");
		    System.out.println("Se acha bonito isso cara.");
		    System.out.println("Agora responde.");
		    System.out.println("Você é feio? (Sim = 1 ; Não = 2)");
		    resposta = scanner.nextInt();
		    System.out.println("");
		
		}
		System.out.println("Assumiu né feião :D");
	}
}
