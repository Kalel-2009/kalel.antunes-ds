import java.util.Scanner;

public class exc13 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        int somaPares = 0;
        int somaImpares = 0;

        System.out.print("Quantos números você quer digitar? ");
        int n = entrada.nextInt();

        for (int i = 1; i <= n; i++) {
            System.out.print("Digite um número: ");
            int num = entrada.nextInt();

            if (num % 2 == 0) {
                somaPares += num;
            } else {
                somaImpares += num;
            }
        }

        System.out.println("Soma dos pares: " + somaPares);
        System.out.println("Soma dos ímpares: " + somaImpares);
    }
}