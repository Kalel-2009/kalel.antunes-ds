import java.util.Scanner;

public class Ex20
{
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner (System.in);

        int escolha, escolha1, escolha2;
        
        System.out.println("Alô? (1 = Oi tudo bem? ; 2 = Quem é?)");
        escolha = scanner.nextInt();
        
        switch (escolha)
        {
            case 1: 
                
                System.out.println("Não seu bobão. (1 = Tá falando assim pq? ; 2 = OXI TÁ DOIDÃO?)");
                escolha1 = scanner.nextInt();
                
                switch(escolha1)
                {
                    case 1:
                        
                        System.out.println("PQ EU QUERO. (1 = AE ; 2 = AH NÃO COMO OUSA)");
                        escolha2 = scanner.nextInt();
                        
                        switch(escolha2)
                        {
                            case 1: 
                                System.out.println("SIM TOMA ESSA DESLIGADA [chamada encerrada].");
                                break;
                                
                            case 2: 
                                System.out.println("É VAI SE LASCAR. [chamada encerrada].");
                                break;
                        }
                        break;
                        
                    case 2:
                        
                        System.out.println("DOIDÃO É VOCÊ. (1 = VAI SE LASCAR ; 2 = AE ENT TOMA)");
                        escolha2 = scanner.nextInt();
                    
                        switch(escolha2)
                        {
                            case 1: 
                                System.out.println("VAI VOCÊ BOBOCA. [chamada encerrada].");
                                break;
                                
                            case 2: 
                                System.out.println("[chamada encerrada].");
                                break;
                        }
                        break;
                }
                break;
            
            case 2: 
                
                System.out.println("Primeiro, qual seu filme de terror favorito? (1 = Oxi Pânico, por que? ; 2 = Como assim, Poltergeist por que?)");
                escolha1 = scanner.nextInt();
                
                switch(escolha1)
                {
                    case 1:
                        System.out.println("Ahhhh por nada, fica relax. [chamada encerrada.]");
                        break;
                        
                    case 2:
                        System.out.println("Hummmmm entendi, olha pra trás aí. AHHHHHHHHHHHH [chamada encerrada]");
                        break;
                }
                break;
        }
    }
}