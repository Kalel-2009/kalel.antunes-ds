import java.util.Scanner;

public class Ex19
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);

		int i;
		int impar;
		
		for (i = 0 ; i < 31 ; i++)
		{
		    
		    if (i % 2 != 0)
		    {
		    
		    System.out.println(i);
		    
		    }
		    else
		{
		    
		    
		}
		}
		
		
		
	}
}
