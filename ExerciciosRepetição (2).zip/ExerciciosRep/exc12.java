import java.util.Scanner;
public class exc12
{
    public static void main(String[] args) 
    {
    Scanner entrada = new Scanner(System.in);
    
    System.out.println("Digite um número: ");
    int i = entrada.nextInt();
    
    for (; i >= 0; i-- )
        {
            System.out.println(i);
        }
        
    }
}

