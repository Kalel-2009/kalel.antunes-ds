import java.util.Scanner;

public class Ex17
{
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        String frase;
        int contador = 0;
        
        System.out.println("Digite uma palavra ou frase:");
        frase = scanner.nextLine();
        
        for (int i = 0; i < frase.length(); i++) {
            
            char letra = frase.charAt(i);
            
            if (letra != ' ') {
                contador++;
            }
        }
        
        System.out.println("Quantidade de letras: " + contador);
    }
}