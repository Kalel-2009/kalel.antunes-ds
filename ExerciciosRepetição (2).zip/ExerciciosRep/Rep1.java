import java.util.Scanner;


public class Rep1{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        
        int ini = 0;
        
        System.out.println("Escreva um número");
        int numero = scanner.nextInt();
        
        System.out.println("");
        
        while ( ini < numero  ){
            
            ini++;
            
            System.out.println("Número : " + ini);
            
        }
        
        
    }
}