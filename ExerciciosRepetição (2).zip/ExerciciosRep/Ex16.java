import java.util.Scanner;

public class Ex16
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);
		
		int resposta;
		
		System.out.println("Escreva o primeiro número: ");
		int x = scanner.nextInt();
		System.out.println("Escreva o segundo número: ");
		int y = scanner.nextInt();
		System.out.println("Você quer multiplicar primeiro número pelo outro? (Sim = 1 ; Não = 2)");
		resposta = scanner.nextInt();
		
		while (resposta == 1) 
		{
		    
		    int mult = x*y;
		    x = mult;
		    System.out.println("O resultado é: " + mult);
		    System.out.println("Você quer multiplicar o resultado pelo segundo número? (Sim = 1 ; Não = 2)");
		    resposta = scanner.nextInt();
		    System.out.println("");
		
		}
		System.out.println("Então o resultado final será: " + x);
	}
}
