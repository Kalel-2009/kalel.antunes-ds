
import java.util.Scanner;

public class Rep5 {


    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Escreva o número do seu dia da semana: (1, 2, 3, 4, 5, 6, 7 ou 8)");
        int Numerododia = scanner.nextInt();
        
        switch (Numerododia){
            
            case 1 :
                System.out.println("Hoje é Domingo");
                break;
            case 2 : 
                System.out.println("Hoje é Segunda-Feira");
                break;
            case 3 :
                System.out.println("Hoje é Terça-Feira");
                break;
            case 4 :
                System.out.println("Hoje é Quarta-Feira");
                break;
            case 5 :
                System.out.println("Hoje é Quinta-Feira");
                break;
            case 6:
                System.out.println("Hoje é Sexta-feira");
                break;
            case 7:
                System.out.println("Hoje é Sábado-Feira");
                break;
            default :
                System.out.println("Não existe o dia da semana digitado");
            
        }
        
        
    }
    
}