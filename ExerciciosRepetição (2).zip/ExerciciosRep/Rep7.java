import java.util.Scanner;

public class Rep7 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);



        for (char letra = 'A'; letra <= 'N'; letra += 2) {
            System.out.println("" + letra + (char)(letra + 1));
        }
    

        scanner.close();
    }
}