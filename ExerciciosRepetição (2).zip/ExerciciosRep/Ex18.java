import java.util.Scanner;

public class Ex18
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);

		
		System.out.println("Escreva a sua nota: ");
		int nota = scanner.nextInt();
		
		if(nota >= 7)
		{
		    
		    System.out.println("Você está aprovado, parabéns.");
		    
		}
		else if (nota < 7 & nota >= 5)
		{
		    
		    System.out.println("Você está de recuperação.");
		    
		}
		
		else
		{
		    
		    System.out.println("Você está reprovado.");
		    
		}
	}
}
