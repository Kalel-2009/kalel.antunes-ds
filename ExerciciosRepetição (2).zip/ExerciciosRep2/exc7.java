import java.util.Scanner;

public class exc7 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        int opcao;
        double total = 0;

        do {
            System.out.println("\n=== MENU ===");
            System.out.println("1 - Arroz (R$10)");
            System.out.println("2 - Feijão (R$8)");
            System.out.println("3 - Carne (R$25)");
            System.out.println("4 - Sair");
            System.out.print("Escolha: ");
            opcao = entrada.nextInt();

            switch (opcao) {
                case 1:
                    total += 10;
                    break;
                case 2:
                    total += 8;
                    break;
                case 3:
                    total += 25;
                    break;
                case 4:
                    System.out.println("Finalizando...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }

        } while (opcao != 4);

        System.out.println("Total da compra: R$" + total);
    }
}