import java.util.Scanner;

public class EX10
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);
		
		int i;
		int [] codi = new int [3]; 
		int cod = 0;
		String [] nome = new String [3];
		int [] quant = new int [3];
		int [] preço = new int [3];
		int escolha;
		
		for (i = 0 ; i < 3 ; i++)
		{
		 
		 cod++;
		 codi [i] = cod;
		 System.out.println("O código do produto é " + codi [i] + ".");
		 System.out.println("Escreva o nome do " + cod + "º produto.");
		 nome [i] = scanner.nextLine();
		 System.out.println("Anexe a quantidade do " + cod + "º produto no estoque.");
		 quant [i] = scanner.nextInt();
		 System.out.println("Anexe o preço do " + cod + "º produto.");
		 preço [i] = scanner.nextInt();
		 scanner.nextLine();
		 System.out.println("");
		 
		}
		
		System.out.println("Escreva o código de um dos produtos para consultar o estoque.");
		escolha = scanner.nextInt();
		
		switch (escolha){
		    
		    case 1: 
		        
		        System.out.println("Código"+ codi [0] );
		        System.out.println("Nome: " + nome[0]);
		        System.out.println("Quantidade: " + quant[0]);
		        System.out.println("Preço: " + preço[0]);
		        break;
		    
		    case 2: 
		        
		        System.out.println("Código"+ codi [1] );
		        System.out.println("Nome: " + nome[1]);
		        System.out.println("Quantidade: " + quant[1]);
		        System.out.println("Preço: " + preço[1]);
		        break;
		    
		    case 3: 
		        
		        System.out.println("Código"+ codi [2] );
		        System.out.println("Nome: " + nome[2]);
		        System.out.println("Quantidade: " + quant[2]);
		        System.out.println("Preço: " + preço[2]);
		        break;
		}
		
	}
}
