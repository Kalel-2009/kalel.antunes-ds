import java.util.Scanner;

public class EX8
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);
	    
		System.out.println("Pense num número de 0 à 100.");
		System.out.println("Agora me diga se ele é par ou ímpar: (1 = Par ; 2 = Ímpar)");
		int escolha1 = scanner.nextInt();
		System.out.println("");
		
		int i;
		int x = 0;
		int y = 10;
		int escolha2;
		int num;
		int resposta;
		
		switch (escolha1)
		{
		    case 1:
		        
		        System.out.println("Entendi.");
		        System.out.println("Agora me diga se o número está entre " + x + " e " + y + ". (Sim = 1 ; Não = 2)");
		        escolha2 = scanner.nextInt();
		        System.out.println("");
		        
		        while (escolha2 == 2){
		        
		        x = x + 10;
		        y = y + 10;
		        
		        System.out.println("Agora me diga se o número está entre " + x + " e " + y + ". (Sim = 1 ; Não = 2)");
		        escolha2 = scanner.nextInt();
		        System.out.println("");
		           
		        }
		        
		        num = x;
		        System.out.println("Então o número que você pensou é o número " + num + " ?. (Sim = 1 ; Não = 2)");
		        resposta = scanner.nextInt();
		        System.out.println("");
		        
		        while (resposta == 2){
		            if (num % 2 == 0){
		        
		        num += 2;
		        System.out.println("Então o número que você pensou é o número " + num + " ?. (Sim = 1 ; Não = 2)");
		        resposta = scanner.nextInt();
		        System.out.println("");
		        
		            }
		            
		            else{
		                
		                num = num + 1;
		                
		            }
		        }
		        break;
		        
		   case 2:
		        System.out.println("Entendi.");
		        System.out.println("Agora me diga se o número está entre " + x + " e " + y + ". (Sim = 1 ; Não = 2)");
		        escolha2 = scanner.nextInt();
		        System.out.println("");
		        
		        while (escolha2 == 2){
		        
		        x = x + 10;
		        y = y + 10;
		        
		        System.out.println("Agora me diga se o número está entre " + x + " e " + y + ". (Sim = 1 ; Não = 2)");
		        escolha2 = scanner.nextInt();
		        System.out.println("");
		        
		        }
		        
		        num = x + 1;
		        System.out.println("Então o número que você pensou é o número " + num + " ?. (Sim = 1 ; Não = 2)");
		        resposta = scanner.nextInt();
		        System.out.println("");
		        
		        while (resposta == 2){
		            if (num % 2 != 0){
		        
		        num += 2;
		        System.out.println("Então o número que você pensou é o número " + num + " ?. (Sim = 1 ; Não = 2)");
		        resposta = scanner.nextInt();
		        System.out.println("");
		            }
		            
		            else{
		                
		                num = num + 1;
		                
		            }
		        
		        } 
		        
		        
		        break;
		}
		System.out.println("NA MOSCA ! Pega um mais dificil na próxima :)");
	}
}
