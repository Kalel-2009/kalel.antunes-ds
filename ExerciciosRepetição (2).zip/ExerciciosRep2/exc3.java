import java.util.Scanner;

public class exc3 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        String usuarioCorreto = "admin";
        String senhaCorreta = "1234";

        int tentativas = 0;

        while (tentativas < 3) {
            System.out.print("Usuário: ");
            String usuario = entrada.nextLine();

            System.out.print("Senha: ");
            String senha = entrada.nextLine();

            if (usuario.equals(usuarioCorreto) && senha.equals(senhaCorreta)) {
                System.out.println("Login realizado com sucesso!");
                break;
            } else {
                tentativas++;
                System.out.println("Dados incorretos! Tentativas restantes: " + (3 - tentativas));
            }
        }

        if (tentativas == 3) {
            System.out.println("Acesso bloqueado!");
        }
    }
}