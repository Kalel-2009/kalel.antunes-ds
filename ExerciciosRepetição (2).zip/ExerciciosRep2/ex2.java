import java.util.Scanner;

public class ex2



{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner(System.in);
	    
	    int [] numeros = new int[12];
	    
	    
		for (int i = 1; i < 12; i++){
		    
		    System.out.println("Escreva o " + i +" ° número do seu CPF: " );
		    int numero = scanner.nextInt();
		    numeros [i] = numero;
		    
		}
		
		int soma = (numeros[1]*10)+(numeros[2]*9)+(numeros[3]*8)+(numeros[4]* 7)+(numeros[5]*6)+(numeros[6]*5)+(numeros[7]*4)+(numeros[8]*3)+(numeros[9]*2);
		int resto = soma % 11;
		int dig1;
		
		
		if( resto < 2 )
		{
		    
		    dig1 = 0;
		    
		}
		
		else{
		    
		    dig1 = 11- resto;
		    
		}
		
		int soma2 = (numeros[1]*11)+(numeros[2]*10)+(numeros[3]*9)+(numeros[4]*8)+(numeros[5]* 7)+(numeros[6]*6)+(numeros[7]*5)+(numeros[8]*4)+(numeros[9]*3)+(numeros[10]*2);
		int resto2 = soma2 % 11;
		int dig2;
		
		if( resto2 < 2 )
		{
		    
		    dig2 = 0;
		    
		}
		
		else{
		    
		    dig2 = 11- resto2;
		    
		}
		
		if(numeros[10] == dig1 & numeros[11] == dig2){
		    
		    System.out.println("Seu CPF é válido.");
		    
		}
		
		else{
		    
		    System.out.println("Seu CPF é inválido.");
		    
		}
		
	}
}
