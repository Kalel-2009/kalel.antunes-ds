import java.util.Scanner;

public class EX9
{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner (System.in);
		
		int i;
		int a = 0;
		String [] nome = new String [5];
		int [] serie = new int [5];
		int [] idade = new int [5];
		int [] curso = new int [5];
		int escolha;
		
		for (i = 0 ; i < 5 ; i++)
		{
		 
		 a++;
		 System.out.println("Escreva o nome do " + a + "º aluno.");
		 nome [i] = scanner.nextLine();
		 System.out.println("Anexe a idade do " + a + "º aluno.");
		 idade [i] = scanner.nextInt();
		 System.out.println("Anexe a série do " + a + "º aluno. (1 = 1º Ano ; 2 = 2º Ano ; 3º Ano)");
		 serie [i] = scanner.nextInt();
		 System.out.println("Anexe a curso do " + a + "º aluno. (1 = DS ; 2 = ADM ; 3 = MK)");
		 curso [i] = scanner.nextInt();
		 scanner.nextLine();
		 
		}
		
		System.out.println("Escolha um dos alunos para consultar seus dados.");
		escolha = scanner.nextInt();
		
		switch (escolha){
		    
		    case 1: 
		        
		        System.out.println("Nome: " + nome[0]);
		        System.out.println("Idade: " + idade[0]);
		        System.out.println("Série: " + serie[0]);
		        System.out.println("Curso: " + curso[0] + ("1 = DS ; 2 = ADM ; 3 = MK"));
		        break;
		    
		    case 2: 
		        
		        System.out.println("Nome: " + nome[1]);
		        System.out.println("Idade: " + idade[1]);
		        System.out.println("Série: " + serie[1]);
		        System.out.println("Curso: " + curso[1] + ("1 = DS ; 2 = ADM ; 3 = MK"));
		        break;
		    
		    case 3: 
		        
		        System.out.println("Nome: " + nome[2]);
		        System.out.println("Idade: " + idade[2]);
		        System.out.println("Série: " + serie[2]);
		        System.out.println("Curso: " + curso[2] + ("1 = DS ; 2 = ADM ; 3 = MK"));
		        break;
		    
		    case 4: 
		        
		        System.out.println("Nome: " + nome[3]);
		        System.out.println("Idade: " + idade[3]);
		        System.out.println("Série: " + serie[3]);
		        System.out.println("Curso: " + curso[3] + ("1 = DS ; 2 = ADM ; 3 = MK"));
		        break;
		    
		    case 5: 
		        
		        System.out.println("Nome: " + nome[4]);
		        System.out.println("Idade: " + idade[4]);
		        System.out.println("Série: " + serie[4]);
		        System.out.println("Curso: " + curso[4] + ("1 = DS ; 2 = ADM ; 3 = MK"));
		        break;
		}
		
	}
}
