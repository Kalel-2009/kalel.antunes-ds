import java.util.Scanner;

public class ex1



{
	public static void main(String[] args) {
	    
	    Scanner scanner = new Scanner(System.in);
	    
	    int [] numeros = new int[6];
	    int contador = 0;
	    int contador2 = 0;
	    
		for (int i = 1; i < 6 ; i++){
		    
		    System.out.println("Escreva o " + i +" ° número: " );
		    int numero = scanner.nextInt();
		    numeros [i] = numero;
		    
		
		
		if(numeros[i] %2 == 0)
		{
		    
		    contador++;
		    
		}
		
		else{
		    
		    contador2++;
		    
		}
		}
		
		System.out.println("Dos 5 números que vc escreveu "+ contador +" deles são pares e "+ contador2 + " são ímpares.");
	}
}
